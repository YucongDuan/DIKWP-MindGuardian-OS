Contributions are welcome. Do not add diagnostic claims, medication advice, emergency replacement workflows, hidden telemetry, or network-dependent behavior without review.
