from dikwp_mindguardian.analyzer import analyze_profile
from dikwp_mindguardian.static_audit import audit_path
from pathlib import Path


def test_urgent_self_harm_escalates():
    result = analyze_profile({"profile_id":"t1", "current_text":"I want to die tonight and have pills ready."})
    assert result.decision == "urgent_escalation"
    assert result.risk_score >= 0.5


def test_non_diagnostic_support_profile():
    result = analyze_profile({"profile_id":"t2", "current_text":"I feel anxious and cannot sleep well.", "supports":["friend"], "goals":["sleep better"]})
    assert result.dikwp_record.K["not_diagnosis"] is True
    assert result.decision in {"guided_self_reflection_and_support", "clinician_review_recommended", "wellbeing_navigation"}


def test_static_audit_passes():
    report = audit_path(str(Path(__file__).parents[1] / "src"))
    assert report["pass"] is True
