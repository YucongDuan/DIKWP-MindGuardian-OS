Be respectful, evidence-oriented, privacy-conscious, and non-stigmatizing.
