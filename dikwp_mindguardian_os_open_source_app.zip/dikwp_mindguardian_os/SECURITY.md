Report security issues privately. This tool should not collect health data by default and should remain offline-first.
