# Source Synthesis

The design synthesizes:

- DIKWP energy/information/intent theory: mental health work has energy cost, information overload risk, and purpose-layer continuity.
- DIKWP-Mesh runtime: evidence and prior separation, residual preservation, reliability gradient, kill/recovery, action boundary.
- Life-centered consciousness theory: distress and affect are embodied and homeostatic; software analysis must not be equated with subjective experience or clinical authority.
- Public-health mental-health direction: community, primary-care, non-specialist, evidence-based, accessible and safety-aware support.

The result is a non-diagnostic active mental-health navigation system.
