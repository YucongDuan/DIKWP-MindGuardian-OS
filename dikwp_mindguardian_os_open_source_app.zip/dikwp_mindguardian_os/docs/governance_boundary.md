# Governance Boundary

## Allowed

- Self-reflection and journaling support.
- Crisis-boundary detection and escalation prompts.
- Clinician handoff preparation.
- Privacy/consent ledger.
- Community outreach prioritization without diagnosis.
- Non-stigmatizing psychoeducation prompts.

## Not Allowed

- Diagnosis or differential diagnosis.
- Medication advice.
- Replacement of therapy, emergency service, or licensed care.
- Suicide method discussion or harm facilitation.
- Coercive monitoring or hidden surveillance.
- Employer, insurer, school, or authority use for punitive decisions.
- Automated decisions on detention, employment, insurance, benefits, or access to care.
- Saving or sharing health data without consent except where immediate safety and local law require emergency action.

## Kill Conditions

- User has immediate self-harm risk, active plan, means, or cannot stay safe.
- Risk to others is imminent.
- Severe withdrawal, delirium, confusion, seizure, or medical emergency.
- Psychosis/mania signals with dangerous behavior or prolonged sleep loss.
- Abuse/safeguarding risk requiring specialist support.
