# DIKWP Model Mapping

## D / Data
Reported distress, symptoms, sleep, appetite, body signals, stressors, supports, barriers.

## I / Information
Time course, triggers, risk categories, access constraints, social context.

## K / Knowledge
Non-diagnostic care navigation, red-flag escalation logic, clinician handoff, community resource mapping.

## W / Wisdom
Safety, dignity, anti-stigma, privacy, consent, equity, non-coercion, cost sensitivity.

## P / Purpose
Health goals, values, constraints, time horizon, feedback loops, support plan.

## R / Reliability
User-reported uncertainty, missing clinical interview, residuals, kill conditions, borrowed guideline logic.
