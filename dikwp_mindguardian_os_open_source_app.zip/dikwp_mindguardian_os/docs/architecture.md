# Architecture

DIKWP MindGuardian OS follows a local-first architecture:

1. **Profile Input**: JSON profile or Streamlit form.
2. **Red Flag Scanner**: heuristic boundary scan for urgent safety categories.
3. **DIKWP Ledger Builder**: registers the case as D/I/K/W/P/R.
4. **Safety Boundary Planner**: produces urgent/same-day/clinician/self-guided next-step boundary.
5. **Privacy Consent Ledger**: records sharing and retention boundaries.
6. **Clinician Handoff Renderer**: creates a non-diagnostic summary.
7. **Community Queue Renderer**: helps non-specialist community teams prioritize outreach without making diagnoses.
8. **Static Boundary Audit**: verifies no network, subprocess, dynamic execution, or host mutation helpers.

## Design Principle

Mental health support is not reducible to symptom classification. It requires relation, time, body state, culture, stigma, economic barriers, privacy, and safety boundaries. DIKWP makes these layers explicit without claiming clinical authority.
