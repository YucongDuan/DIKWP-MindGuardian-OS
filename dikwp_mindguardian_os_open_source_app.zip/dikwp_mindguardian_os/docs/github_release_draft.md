# Release Draft: DIKWP MindGuardian OS v0.1.0

We are releasing DIKWP MindGuardian OS, an open-source, offline-first mental health navigation and safety-boundary ledger.

Highlights:
- Red-flag boundary scan.
- DIKWP mental-health ledger.
- Safety boundary plan.
- Clinician handoff note.
- Privacy and consent ledger.
- Community support queue.
- No diagnosis, no medication advice, no emergency replacement.

This is part of the DIKWP TrustOS open-source application family.
