# Roadmap

## v0.1
Offline profile analyzer, red flags, DIKWP ledger, handoff, consent ledger.

## v0.2
Localization packs, school/EAP/community templates, crisis-resource directory.

## v0.3
FHIR-style consent-aware handoff, longitudinal feedback, MemoryLedger integration.

## v0.4
ProofLedger psychoeducation citations, IntentGuard crisis prompt boundary, AgentTrace outreach audit.

## v1.0
Clinician-reviewed guideline packs, community deployment pilots, privacy/security review, accessibility testing.
