# Integration Guide

## Local CLI
Use the CLI for offline analysis of a JSON profile.

## Community Workflow
A community worker can run a batch file and use `community_support_queue.csv` to prioritize non-diagnostic outreach.

## Clinician Workflow
The user can bring `clinician_handoff.md` to a licensed clinician. This improves communication but does not determine diagnosis or treatment.

## Future Integrations
- FHIR / SMART-on-FHIR consent-aware handoff.
- Local crisis-resource directory.
- Translation integrity pack.
- ProofLedger for evidence-backed psychoeducation.
- MemoryLedger for user-controlled longitudinal mental-health notes.
- AgentTrace for support workflow audit.
