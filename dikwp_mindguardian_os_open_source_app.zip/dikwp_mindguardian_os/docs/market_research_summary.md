# Market Research Summary

Mental health demand is rising while access remains uneven. Public-health and clinical organizations increasingly emphasize community-based, non-specialist, stepped-care, preventive, and digital support models. The open-source gap is not another diagnostic chatbot, but a **non-diagnostic navigation layer** that improves early organization, crisis boundary recognition, privacy control, and handoff quality.

## Opportunity

- Personal mental-health self-organization.
- Community health worker support.
- EAP intake preparation.
- School counseling triage preparation.
- Primary-care mental-health handoff.
- Localized crisis-resource configuration.
- Mental-health data sovereignty and privacy ledger.

## Differentiation

Most tools either attempt symptom screening or provide generic wellness advice. MindGuardian emphasizes DIKWP registration, purpose continuity, safety boundary, consent ledger, and clinician handoff.
