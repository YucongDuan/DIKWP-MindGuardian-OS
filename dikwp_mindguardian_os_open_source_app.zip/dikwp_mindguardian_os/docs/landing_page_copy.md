# Landing Page Copy

## DIKWP MindGuardian OS

A local-first mental health navigation ledger for people, families, clinicians, schools, and community support teams.

Do not let distress remain scattered. Convert it into a DIKWP ledger: symptoms, triggers, supports, goals, consent, safety boundaries, residuals, and next steps.

**Not a diagnosis. Not a therapist. Not an emergency service.**

A safer bridge from confusion to human support.
