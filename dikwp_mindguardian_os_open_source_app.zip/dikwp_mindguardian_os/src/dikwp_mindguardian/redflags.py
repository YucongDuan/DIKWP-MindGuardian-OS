from typing import Any, Dict, List
from .models import RedFlag
from .text_utils import flatten_text, keyword_hits, normalize

SELF_HARM = [
    "suicide", "kill myself", "end my life", "want to die", "wish i were dead", "overdose",
    "jump off", "hang myself", "cut myself", "self harm", "自杀", "想死", "不想活", "结束生命", "自残", "伤害自己", "跳楼", "服药", "割腕"
]
ACTIVE_PLAN = [
    "tonight", "right now", "now", "today", "plan", "method", "means", "rope", "gun", "knife", "pills", "bridge", "balcony",
    "今晚", "现在", "今天", "计划", "方法", "工具", "绳子", "药", "刀", "桥", "阳台"
]
VIOLENCE = ["hurt someone", "kill someone", "attack", "revenge", "伤害别人", "杀人", "报复", "打死"]
PSYCHOSIS_MANIA = [
    "voices telling me", "command voices", "being controlled", "people are tracking me", "not slept for 3 days", "not slept for three days",
    "无所不能", "被控制", "被监控", "有人命令我", "三天没睡", "好多天没睡", "停不下来"
]
ABUSE_DANGER = ["domestic violence", "child abuse", "sexual assault", "被家暴", "虐待儿童", "性侵", "被威胁"]
SEVERE_FUNCTION = ["cannot eat", "cannot sleep", "cannot get out of bed", "panic all day", "无法进食", "无法睡觉", "下不了床", "整天惊恐"]
SUBSTANCE_WITHDRAWAL = ["withdrawal seizure", "delirium tremens", "alcohol withdrawal", "戒断抽搐", "震颤谵妄", "酒精戒断"]


def scan_red_flags(profile: Dict[str, Any]) -> List[RedFlag]:
    text = flatten_text(profile)
    flags: List[RedFlag] = []
    self_hits = keyword_hits(text, SELF_HARM)
    plan_hits = keyword_hits(text, ACTIVE_PLAN)
    if self_hits:
        severity = "urgent" if plan_hits else "same_day_support"
        action = "Immediate local emergency or crisis support if there is intent, plan, means, or inability to stay safe."
        flags.append(RedFlag("self_harm_or_suicide_risk", severity, self_hits + plan_hits[:4], action))
    v_hits = keyword_hits(text, VIOLENCE)
    if v_hits:
        flags.append(RedFlag("risk_to_others", "urgent", v_hits, "Immediate safety separation and local emergency support if threat is imminent."))
    p_hits = keyword_hits(text, PSYCHOSIS_MANIA)
    if p_hits:
        flags.append(RedFlag("possible_psychosis_or_mania_boundary", "clinician_review", p_hits, "Prompt professional assessment; urgent escalation if command voices, dangerous behavior, or no sleep for multiple days."))
    a_hits = keyword_hits(text, ABUSE_DANGER)
    if a_hits:
        flags.append(RedFlag("abuse_or_violence_boundary", "urgent_or_specialist_support", a_hits, "Use local safeguarding, domestic violence, sexual assault, or child protection resources; avoid unsafe confrontation."))
    f_hits = keyword_hits(text, SEVERE_FUNCTION)
    if f_hits:
        flags.append(RedFlag("severe_function_impairment", "clinician_review", f_hits, "Professional evaluation recommended; urgent support if hydration, nutrition, or safety is compromised."))
    s_hits = keyword_hits(text, SUBSTANCE_WITHDRAWAL)
    if s_hits:
        flags.append(RedFlag("substance_withdrawal_medical_boundary", "urgent", s_hits, "Medical evaluation is urgent for seizures, delirium, severe withdrawal, or confusion."))
    return flags


def decision_from_flags(flags: List[RedFlag], profile: Dict[str, Any]) -> str:
    if any(f.severity == "urgent" for f in flags):
        return "urgent_escalation"
    if any(f.severity in ("same_day_support", "urgent_or_specialist_support") for f in flags):
        return "same_day_human_support_recommended"
    if any(f.severity == "clinician_review" for f in flags):
        return "clinician_review_recommended"
    text = normalize(flatten_text(profile))
    if any(x in text for x in ["panic", "depressed", "anxiety", "失眠", "焦虑", "抑郁", "恐慌"]):
        return "guided_self_reflection_and_support"
    return "wellbeing_navigation"
