from pathlib import Path
from typing import Dict, Any, List
import ast, json

FORBIDDEN_IMPORTS = {"requests", "urllib", "httpx", "socket", "subprocess", "ftplib", "telnetlib"}
FORBIDDEN_CALL_NAMES = {"eval", "exec", "compile", "__import__"}
HOST_MUTATION_HINTS = ["os.system", "shutil.rmtree", "Path.unlink", "Path.rmdir"]


def audit_path(path: str) -> Dict[str, Any]:
    root = Path(path)
    findings: List[Dict[str, Any]] = []
    for py in root.rglob("*.py"):
        try:
            tree = ast.parse(py.read_text(encoding="utf-8"))
        except Exception as e:
            findings.append({"file": str(py), "type": "parse_error", "detail": str(e)})
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for name in node.names:
                    base = name.name.split('.')[0]
                    if base in FORBIDDEN_IMPORTS:
                        findings.append({"file": str(py), "type": "forbidden_import", "detail": name.name})
            elif isinstance(node, ast.ImportFrom):
                mod = (node.module or '').split('.')[0]
                if mod in FORBIDDEN_IMPORTS:
                    findings.append({"file": str(py), "type": "forbidden_import", "detail": node.module})
            elif isinstance(node, ast.Call):
                if isinstance(node.func, ast.Name) and node.func.id in FORBIDDEN_CALL_NAMES:
                    findings.append({"file": str(py), "type": "forbidden_call", "detail": node.func.id})
    return {
        "pass": len(findings) == 0,
        "finding_count": len(findings),
        "findings": findings,
        "policy": "No network imports, subprocess, dynamic execution, or host mutation helpers."
    }


def write_audit(path: str, out_file: str) -> Dict[str, Any]:
    report = audit_path(path)
    Path(out_file).parent.mkdir(parents=True, exist_ok=True)
    Path(out_file).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report
