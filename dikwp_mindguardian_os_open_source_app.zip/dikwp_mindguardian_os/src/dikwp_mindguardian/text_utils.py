import re
from typing import Any, Iterable, List

def flatten_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        return " ".join(flatten_text(v) for v in value.values())
    if isinstance(value, list):
        return " ".join(flatten_text(v) for v in value)
    return str(value)

def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", text.lower()).strip()

def keyword_hits(text: str, keywords: Iterable[str]) -> List[str]:
    t = normalize(text)
    hits = []
    for kw in keywords:
        k = kw.lower()
        if k in t:
            hits.append(kw)
    return sorted(set(hits))

def clamp(x: float, low: float = 0.0, high: float = 1.0) -> float:
    return max(low, min(high, x))
