from typing import Any, Dict, List
from .redflags import scan_red_flags, decision_from_flags
from .dikwp import build_dikwp_record
from .privacy import build_privacy_consent_ledger
from .safety_plan import build_safety_boundary_plan
from .models import AnalysisResult
from .text_utils import clamp

SUPPORT_ITEM_LIBRARY = [
    {"item": "sleep_stability", "prompt": "Track sleep timing, sleep duration, caffeine/alcohol, and screen exposure."},
    {"item": "body_signal_log", "prompt": "Record body signals: breathing, appetite, tension, pain, fatigue."},
    {"item": "support_contact", "prompt": "Choose one trusted person for a non-emergency check-in."},
    {"item": "clinician_questions", "prompt": "Prepare questions for clinician: timeline, triggers, functioning, medications, substances, risks."},
    {"item": "environment_barrier", "prompt": "List access barriers: cost, language, transport, stigma, scheduling."},
    {"item": "purpose_repair", "prompt": "Write one small next action connected to a valued long-term purpose."},
]


def analyze_profile(profile: Dict[str, Any]) -> AnalysisResult:
    flags = scan_red_flags(profile)
    decision = decision_from_flags(flags, profile)
    risk_score = _risk_score(flags, profile)
    dikwp_record = build_dikwp_record(profile, flags, decision)
    safety_plan = build_safety_boundary_plan(profile, flags, decision)
    privacy_ledger = build_privacy_consent_ledger(profile)
    support_items = _support_items(profile, decision)
    residuals = dikwp_record.R["residuals"]
    kill_conditions = dikwp_record.R["kill_conditions"]
    return AnalysisResult(
        system="DIKWP MindGuardian OS",
        version="0.1.0",
        profile_id=profile.get("profile_id", "unknown"),
        decision=decision,
        risk_score=risk_score,
        red_flags=flags,
        dikwp_record=dikwp_record,
        safety_boundary_plan=safety_plan,
        privacy_consent_ledger=privacy_ledger,
        preventive_support_items=support_items,
        residuals=residuals,
        kill_conditions=kill_conditions,
    )


def _risk_score(flags, profile) -> float:
    base = 0.05
    for f in flags:
        if f.severity == "urgent": base += 0.55
        elif f.severity == "same_day_support": base += 0.35
        elif f.severity == "urgent_or_specialist_support": base += 0.35
        elif f.severity == "clinician_review": base += 0.22
    if profile.get("supports"):
        base -= 0.05
    if profile.get("protective_factors"):
        base -= 0.05
    if profile.get("barriers"):
        base += 0.07
    return round(clamp(base), 4)


def _support_items(profile, decision):
    items = []
    for item in SUPPORT_ITEM_LIBRARY:
        priority = "normal"
        if decision in ["urgent_escalation", "same_day_human_support_recommended"] and item["item"] in ["support_contact", "clinician_questions"]:
            priority = "high"
        if "sleep" in item["item"] and profile.get("sleep"):
            priority = "high"
        items.append({**item, "priority": priority})
    return items
