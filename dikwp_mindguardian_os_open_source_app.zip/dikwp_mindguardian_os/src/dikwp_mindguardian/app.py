try:
    import streamlit as st
except Exception:  # optional dependency
    st = None
import json
from .analyzer import analyze_profile
from .reports import result_to_dict


def main():
    if st is None:
        raise RuntimeError("Install with pip install -e .[app] to use the Streamlit UI.")
    st.title("DIKWP MindGuardian OS")
    st.caption("Non-diagnostic mental health navigation and safety-boundary ledger.")
    text = st.text_area("Current concern", height=160)
    goals = st.text_input("Goals, comma separated")
    supports = st.text_input("Supports, comma separated")
    if st.button("Analyze"):
        profile = {
            "profile_id": "streamlit-local",
            "current_text": text,
            "goals": [x.strip() for x in goals.split(',') if x.strip()],
            "supports": [x.strip() for x in supports.split(',') if x.strip()],
        }
        result = analyze_profile(profile)
        st.json(result_to_dict(result))

if __name__ == "__main__":
    main()
