from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class RedFlag:
    category: str
    severity: str
    evidence: List[str]
    action: str
    reliability: str = "Supported / heuristic"

@dataclass
class DIKWPRecord:
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]

@dataclass
class AnalysisResult:
    system: str
    version: str
    profile_id: str
    decision: str
    risk_score: float
    red_flags: List[RedFlag]
    dikwp_record: DIKWPRecord
    safety_boundary_plan: Dict[str, Any]
    privacy_consent_ledger: Dict[str, Any]
    preventive_support_items: List[Dict[str, Any]] = field(default_factory=list)
    residuals: List[str] = field(default_factory=list)
    kill_conditions: List[str] = field(default_factory=list)
