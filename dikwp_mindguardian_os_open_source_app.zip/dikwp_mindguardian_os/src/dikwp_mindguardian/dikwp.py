from typing import Any, Dict, List
from .models import DIKWPRecord, RedFlag

def build_dikwp_record(profile: Dict[str, Any], flags: List[RedFlag], decision: str) -> DIKWPRecord:
    D = {
        "profile_id": profile.get("profile_id", "unknown"),
        "reported_text": profile.get("current_text", ""),
        "symptoms_or_states": profile.get("symptoms", []),
        "sleep": profile.get("sleep", {}),
        "stressors": profile.get("stressors", []),
        "protective_factors": profile.get("protective_factors", []),
        "supports": profile.get("supports", []),
    }
    I = {
        "time_course": profile.get("time_course", "unknown"),
        "triggers": profile.get("triggers", []),
        "access_barriers": profile.get("barriers", []),
        "risk_boundary_categories": [f.category for f in flags],
        "decision": decision,
    }
    K = {
        "interpretation": "Non-diagnostic mental health navigation and safety-boundary assessment.",
        "care_navigation": "Use red flags to decide whether to seek urgent, same-day, clinician, peer, or self-guided support.",
        "not_diagnosis": True,
    }
    W = {
        "privacy": "Local-first. Share only with explicit consent or when immediate safety risk requires emergency escalation.",
        "dignity": "Avoid shame, moral blame, coercive labels, and identity reduction.",
        "equity": profile.get("equity_context", {}),
        "safety_first": decision in ["urgent_escalation", "same_day_human_support_recommended"],
    }
    P = {
        "goals": profile.get("goals", []),
        "values": profile.get("values", []),
        "constraints": profile.get("constraints", []),
        "time_horizon": profile.get("time_horizon", "next_24h_and_next_2_weeks"),
        "feedback": "Review state daily in acute stress, weekly in stabilization, and after major events.",
    }
    R = {
        "reliability": "Provisional / user-reported / heuristic",
        "residuals": [
            "No clinical interview performed.",
            "No diagnosis inferred.",
            "No medication or treatment plan generated.",
            "Cultural, medical, substance, trauma, and environmental factors may be incomplete.",
        ],
        "kill_conditions": [
            "Any self-harm plan, intent, means, or inability to stay safe.",
            "Psychosis/mania signals with dangerous behavior or severe sleep loss.",
            "Violence, abuse, severe withdrawal, confusion, or medical emergency.",
        ],
    }
    return DIKWPRecord(D, I, K, W, P, R)
