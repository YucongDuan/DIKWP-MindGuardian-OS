from typing import Any, Dict

def build_privacy_consent_ledger(profile: Dict[str, Any]) -> Dict[str, Any]:
    consent = profile.get("consent", {})
    return {
        "profile_id": profile.get("profile_id", "unknown"),
        "data_minimization": True,
        "local_first": True,
        "default_external_sharing": "disabled",
        "consent_to_share_with_clinician": bool(consent.get("share_with_clinician", False)),
        "consent_to_share_with_support_person": bool(consent.get("share_with_support_person", False)),
        "consent_to_share_with_community_worker": bool(consent.get("share_with_community_worker", False)),
        "emergency_exception_boundary": "If imminent risk to life or safety is detected, local law and emergency norms may require urgent escalation.",
        "sensitive_fields": ["mental_health_notes", "trauma", "substance_use", "medications", "contacts", "location", "identity"],
        "recommended_retention": consent.get("retention", "user-controlled; default delete after review"),
    }
