from pathlib import Path
import argparse, json
from .analyzer import analyze_profile
from .reports import write_single_outputs, write_batch_outputs
from .static_audit import write_audit


def main() -> None:
    parser = argparse.ArgumentParser(prog="mindguardian")
    sub = parser.add_subparsers(dest="cmd", required=True)
    p1 = sub.add_parser("analyze")
    p1.add_argument("profile")
    p1.add_argument("--out", default="outputs/demo")
    p2 = sub.add_parser("batch")
    p2.add_argument("batch_file")
    p2.add_argument("--out", default="outputs/demo")
    p3 = sub.add_parser("static-audit")
    p3.add_argument("path")
    p3.add_argument("--out", default="outputs/demo/static_boundary_audit_report.json")
    args = parser.parse_args()
    if args.cmd == "analyze":
        profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
        result = analyze_profile(profile)
        write_single_outputs(result, Path(args.out))
        print(json.dumps({"decision": result.decision, "risk_score": result.risk_score, "red_flags": len(result.red_flags)}, ensure_ascii=False))
    elif args.cmd == "batch":
        data = json.loads(Path(args.batch_file).read_text(encoding="utf-8"))
        profiles = data.get("profiles", data if isinstance(data, list) else [])
        results = [analyze_profile(p) for p in profiles]
        write_batch_outputs(results, Path(args.out))
        print(json.dumps({"count": len(results), "urgent": sum(r.decision == "urgent_escalation" for r in results)}, ensure_ascii=False))
    elif args.cmd == "static-audit":
        report = write_audit(args.path, args.out)
        print(json.dumps(report, ensure_ascii=False))

if __name__ == "__main__":
    main()
