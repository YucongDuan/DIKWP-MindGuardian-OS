from dataclasses import asdict
from pathlib import Path
from typing import Dict, Any, List
import csv, json
from .models import AnalysisResult


def result_to_dict(result: AnalysisResult) -> Dict[str, Any]:
    return asdict(result)


def write_single_outputs(result: AnalysisResult, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    d = result_to_dict(result)
    (out_dir / "mindguardian_report.json").write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "dikwp_mental_health_ledger.json").write_text(json.dumps(d["dikwp_record"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "safety_boundary_plan.json").write_text(json.dumps(d["safety_boundary_plan"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "privacy_consent_ledger.json").write_text(json.dumps(d["privacy_consent_ledger"], ensure_ascii=False, indent=2), encoding="utf-8")
    (out_dir / "clinician_handoff.md").write_text(render_clinician_handoff(result), encoding="utf-8")
    (out_dir / "recommendations.md").write_text(render_recommendations(result), encoding="utf-8")


def write_batch_outputs(results: List[AnalysisResult], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / "community_support_queue.csv"
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["profile_id", "decision", "risk_score", "red_flag_count", "top_flags"])
        writer.writeheader()
        for r in sorted(results, key=lambda x: x.risk_score, reverse=True):
            writer.writerow({
                "profile_id": r.profile_id,
                "decision": r.decision,
                "risk_score": r.risk_score,
                "red_flag_count": len(r.red_flags),
                "top_flags": ";".join([f.category for f in r.red_flags[:3]]),
            })
    batch = [result_to_dict(r) for r in results]
    (out_dir / "community_batch_report.json").write_text(json.dumps(batch, ensure_ascii=False, indent=2), encoding="utf-8")


def render_clinician_handoff(result: AnalysisResult) -> str:
    r = result
    flags = "\n".join([f"- {f.category} ({f.severity}): {', '.join(f.evidence)}" for f in r.red_flags]) or "- No red-flag boundary detected by heuristic scan."
    goals = ", ".join(r.dikwp_record.P.get("goals", [])) or "not provided"
    return f"""# Clinician Handoff Note\n\n**Profile ID:** {r.profile_id}\n\n**Decision:** {r.decision}\n\n**Risk score:** {r.risk_score}\n\n## Reported Concerns\n{r.dikwp_record.D.get('reported_text','')}\n\n## Red Flag Boundaries\n{flags}\n\n## Current Goals / Purpose Layer\n{goals}\n\n## Protective Factors / Supports\n{', '.join(r.dikwp_record.D.get('protective_factors', [])) or 'not provided'}\n\n## Residuals\n- No diagnosis is inferred.\n- This is a user-reported, non-clinical navigation summary.\n- Please assess risk, functioning, sleep, substances, trauma, medical contributors, and current safety directly.\n"""


def render_recommendations(result: AnalysisResult) -> str:
    items = "\n".join([f"- **{x['priority']}**: {x['prompt']}" for x in result.preventive_support_items])
    return f"""# DIKWP MindGuardian Recommendations\n\nDecision: **{result.decision}**\n\nThis tool is non-diagnostic. Use it to organize concerns, questions, evidence, uncertainty, and safety boundaries.\n\n## Immediate Boundary\n{'; '.join(result.safety_boundary_plan.get('do_now', []))}\n\n## Support Items\n{items}\n\n## Kill Conditions\n{chr(10).join('- ' + k for k in result.kill_conditions)}\n\n## Action Boundary\nDo not use this output to delay emergency care, diagnose yourself or others, prescribe treatment, or make irreversible decisions while safety risk is unresolved.\n"""
