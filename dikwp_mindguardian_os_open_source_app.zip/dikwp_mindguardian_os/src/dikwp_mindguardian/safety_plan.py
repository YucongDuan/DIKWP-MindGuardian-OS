from typing import Any, Dict, List
from .models import RedFlag

def build_safety_boundary_plan(profile: Dict[str, Any], flags: List[RedFlag], decision: str) -> Dict[str, Any]:
    supports = profile.get("supports", [])
    coping = profile.get("coping_strategies", []) or [
        "slow breathing or grounding for 2-5 minutes",
        "step away from unsafe locations or escalating conversations",
        "contact one trusted person",
        "reduce access to obvious hazards if safe to do so",
        "write down the next smallest safe action",
    ]
    local_resources = profile.get("local_crisis_resources", []) or [
        "local emergency number",
        "local crisis hotline or emergency department",
        "trusted clinician or community health worker",
    ]
    return {
        "decision": decision,
        "red_flag_count": len(flags),
        "urgent_boundary": decision == "urgent_escalation",
        "do_now": _do_now(decision),
        "warning_signs_to_monitor": [f.category for f in flags] or ["worsening distress", "loss of sleep", "social withdrawal", "hopelessness", "panic escalation"],
        "coping_options": coping,
        "support_contacts": supports,
        "professional_or_crisis_resources": local_resources,
        "environment_safety_note": "For imminent danger, do not rely on self-help content. Move toward people, safer space, and emergency support.",
        "next_review": "immediately for urgent boundary; within 24h for same-day support; within 1-2 weeks for guided navigation",
    }

def _do_now(decision: str) -> List[str]:
    if decision == "urgent_escalation":
        return [
            "Contact local emergency service or crisis line now if immediate danger is possible.",
            "Do not remain alone if safety is uncertain; move toward a trusted person or safe public/clinical setting.",
            "Stop using this tool as the primary support until human safety support is engaged.",
        ]
    if decision == "same_day_human_support_recommended":
        return [
            "Contact a trusted person, clinician, crisis line, or local support service today.",
            "Create a short safety check-in plan for the next 24 hours.",
            "Avoid major irreversible decisions while distress is high.",
        ]
    if decision == "clinician_review_recommended":
        return [
            "Prepare the clinician handoff note and seek professional assessment.",
            "Track sleep, appetite, functioning, substances, and risk signals.",
            "Use support contacts if distress escalates.",
        ]
    return [
        "Use the ledger to clarify stressors, goals, protective factors, and next small action.",
        "Review patterns and seek human support if symptoms worsen or persist.",
    ]
