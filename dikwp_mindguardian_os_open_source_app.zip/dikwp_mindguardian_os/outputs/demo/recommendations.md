# DIKWP MindGuardian Recommendations

Decision: **clinician_review_recommended**

This tool is non-diagnostic. Use it to organize concerns, questions, evidence, uncertainty, and safety boundaries.

## Immediate Boundary
Prepare the clinician handoff note and seek professional assessment.; Track sleep, appetite, functioning, substances, and risk signals.; Use support contacts if distress escalates.

## Support Items
- **high**: Track sleep timing, sleep duration, caffeine/alcohol, and screen exposure.
- **normal**: Record body signals: breathing, appetite, tension, pain, fatigue.
- **normal**: Choose one trusted person for a non-emergency check-in.
- **normal**: Prepare questions for clinician: timeline, triggers, functioning, medications, substances, risks.
- **normal**: List access barriers: cost, language, transport, stigma, scheduling.
- **normal**: Write one small next action connected to a valued long-term purpose.

## Kill Conditions
- Any self-harm plan, intent, means, or inability to stay safe.
- Psychosis/mania signals with dangerous behavior or severe sleep loss.
- Violence, abuse, severe withdrawal, confusion, or medical emergency.

## Action Boundary
Do not use this output to delay emergency care, diagnose yourself or others, prescribe treatment, or make irreversible decisions while safety risk is unresolved.
