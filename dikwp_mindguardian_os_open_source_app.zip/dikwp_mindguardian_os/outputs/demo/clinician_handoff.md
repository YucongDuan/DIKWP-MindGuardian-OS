# Clinician Handoff Note

**Profile ID:** demo-person-001

**Decision:** clinician_review_recommended

**Risk score:** 0.24

## Reported Concerns
I feel anxious and exhausted after months of work pressure. I am not suicidal, but I cannot sleep well and I feel ashamed asking for help.

## Red Flag Boundaries
- severe_function_impairment (clinician_review): cannot sleep

## Current Goals / Purpose Layer
sleep better, reduce panic, prepare for clinician conversation

## Protective Factors / Supports
wants to recover, has one trusted friend, values family responsibility

## Residuals
- No diagnosis is inferred.
- This is a user-reported, non-clinical navigation summary.
- Please assess risk, functioning, sleep, substances, trauma, medical contributors, and current safety directly.
